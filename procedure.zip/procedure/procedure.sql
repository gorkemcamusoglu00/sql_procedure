--stored procedure sql komutlar�n� veri taban�nda saklar
--her ihtiya� duydu�unda sadece ilgili parametrelerle �al���rs�n�z
--her defas�nda s�f�rdan kod yaz�lmaz
--bir procedure isimlendirilirken ba��na sp k�saltmas� eklenerek bunun stored procedure oldu�u belirtilir
--parametre kullan�lacaksa parametre �ncesi @ kullan�l�r


create procedure
as
begin
--i�lem yapaca��n sql komutu
end


CREATE PROCEDURE sp_insert_into_Table_Customer
@customer_name nvarchar(50),
@customer_surname nvarchar(50),
@customer_age  tinyint,
@gender_id tinyint
as
begin
insert into Table_Customer(
customer_name, customer_surname, customer_age, gender_id)

values
(@customer_name, @customer_surname, @customer_age, @gender_id)
end

--bir stored procedure �al��t�rmak i�in isimden �nce execute yada k�saca exce yazmak gerekir

exec sp_insert_into_Table_Customer
@customer_name='G�rkem',
@customer_surname='Camuso�lu',
@customer_age =20,
@gender_id =1

--update i�in procedure
create procedure sp_update_Table_Customer
@customer_id int,
@customer_name nvarchar(50),
@customer_surname nvarchar(50),
@customer_age  tinyint,
@gender_id tinyint

as
begin

update Table_Customer set
customer_name=@customer_name,
customer_surname=@customer_surname,
customer_age=@customer_age,
gender_id=@gender_id

where customer_id=@customer_id
end

exec sp_update_Table_Customer
@customer_id=4,
@customer_name='G�rkem',
@customer_surname='Camuso�lu',
@customer_age =25,
@gender_id =1

--delete i�in
create procedure sp_delete_Table_Customer

@customer_id int
as
begin
delete from Table_Customer where customer_id=@customer_id
end

exec sp_delete_Table_Customer
@customer_id=4

--select i�in procedure (bunda parametreye gerek yoktur)

create procedure sp_select_Table_Customer
as
begin
select
tbc.customer_id as 'm��teri id',
tbc.customer_name as 'm��teri ad�',
tbc.customer_surname as'm��teri soyad�',
tbg.gender_name as'cinsiyet'

from Table_Customer tbc
inner join Table_Gender tbg
on tbc.gender_id=tbg.gender_id
end

exec sp_select_Table_Customer